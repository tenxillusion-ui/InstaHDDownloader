# Insta HD Downloader — Android starter project

This is a native Android Kotlin starter project. It accepts text links through Android's Share sheet. If the shared URL is a direct video file URL (`.mp4`, `.m4v`, `.webm`), Android DownloadManager downloads it to `Movies/` and shows a completion notification.

## Important limitation
An Instagram Reel/Post share URL is a web page permalink, not a direct video file URL. This starter intentionally does **not** claim it can extract video media from Instagram. To support Instagram permalinks, the next development step is to integrate a compliant resolver/backend that can retrieve media only where access and downloading are authorized, and returns the best available media URL. Private/login-only posts should remain unsupported; never ask users for Instagram passwords or cookies.

## Build APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Choose **Build → Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle installed, so no compiled APK is included. The ZIP contains source code and project configuration, not an installable APK.

## Test
- Run the app on an Android phone.
- In Instagram, use Share and select `Insta HD Downloader`.
- A direct video-file URL can be downloaded automatically. For a normal Instagram Reel/Post link, the app explains that a resolver service is still needed.

## Permissions and privacy
The app does not request Instagram login details. It needs Internet access and uses Android DownloadManager for direct file downloads. Download only content you own or have permission to save, and comply with platform terms and local law.
