package com.ashin.instahd

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Starter app: accepts Android Share text and automatically downloads direct media URLs.
 * Instagram post/reel permalinks need a compliant media-resolution service; a permalink is not
 * itself a video file, so this app deliberately does not pretend it can download every link.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var linkText: TextView
    private var sharedUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        val title = TextView(this).apply { text = "Insta HD Downloader"; textSize = 25f; gravity = Gravity.CENTER }
        status = TextView(this).apply { textSize = 16f; text = "Instagram-ൽ നിന്ന് ഒരു link Share ചെയ്യൂ."; setPadding(0, 28, 0, 18) }
        linkText = TextView(this).apply { textSize = 13f; text = "Shared link ഇവിടെ കാണിക്കും"; setPadding(0, 0, 0, 22) }
        val pasteHelp = TextView(this).apply {
            textSize = 14f
            text = "Direct .mp4 links സ്വയം download ചെയ്യാം. Instagram Reel/Post link-ിന് video URL ലഭ്യമാക്കുന്ന resolver service വേണം. Private/login-only content പിന്തുണയ്ക്കുന്നില്ല."
        }
        val downloadButton = Button(this).apply {
            text = "Try Download"
            setOnClickListener { sharedUrl?.let { handleUrl(it, auto = false) } ?: run { status.text = "ആദ്യം Instagram-ൽ നിന്ന് link Share ചെയ്യൂ." } }
        }
        root.addView(title); root.addView(status); root.addView(linkText); root.addView(pasteHelp); root.addView(downloadButton)
        setContentView(root)
        receiveShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        receiveShare(intent)
    }

    private fun receiveShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        val url = Regex("https?://\\S+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ')', ']')
        if (url.isNullOrBlank()) {
            status.text = "Share ചെയ്ത text-ൽ URL കണ്ടെത്താനായില്ല."
            return
        }
        sharedUrl = url
        linkText.text = url
        handleUrl(url, auto = true)
    }

    private fun handleUrl(url: String, auto: Boolean) {
        val uri = runCatching { Uri.parse(url) }.getOrNull()
        val scheme = uri?.scheme
        if (scheme != "https" && scheme != "http") {
            status.text = "സാധുവായ HTTP/HTTPS link അല്ല."
            return
        }
        val path = uri.path.orEmpty().lowercase()
        val looksLikeVideoFile = path.endsWith(".mp4") || path.endsWith(".m4v") || path.endsWith(".webm")
        if (!looksLikeVideoFile) {
            status.text = "Instagram link ലഭിച്ചു. ഇത് post/reel page link ആണ്; നേരിട്ടുള്ള video file അല്ല. HD download ചെയ്യാൻ അനുവദനീയമായ video resolver service ചേർക്കണം."
            return
        }
        try {
            val request = DownloadManager.Request(uri)
                .setTitle("Instagram video")
                .setDescription("Downloading video")
                .setMimeType("video/mp4")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, "InstaHD_${System.currentTimeMillis()}.mp4")
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = if (auto) "Direct video link കണ്ടെത്തി — download ആരംഭിച്ചു." else "Download ആരംഭിച്ചു."
            Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            status.text = "Download ആരംഭിക്കാനായില്ല: ${e.localizedMessage ?: "unknown error"}"
        }
    }
}
