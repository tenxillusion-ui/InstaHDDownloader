plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ashin.instahd"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ashin.instahd"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
